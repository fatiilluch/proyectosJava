# SES2

DEMO - SES2

Desarrollo de Aplicacion para gestion de Educacional.
Este es un ejemplo de como hacer un CRUD basico con 2 tablas relaccionadas Career (1) ... (n) Student. 

Mira la siguiente DEMO:

[![SES2 - Demo](http://i.imgur.com/4Cj510M.png)](https://youtu.be/tTooYyCpwMI "SES2 - Demo")
