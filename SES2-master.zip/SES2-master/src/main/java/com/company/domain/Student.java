package com.company.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Repository
@Table(name="student")
@SequenceGenerator(name="seq2", initialValue=1, allocationSize=100)
public class Student {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seq2")
	@Column(name="id_student", length=50, nullable=false)
	private Long idStudent;
	
	@Column(name="name", length=50, nullable=false)
	private String name;
	
	@Column(name="username", length=50, nullable=false)
	private String username;
	
	@Column(name="password", length=50, nullable=false)
	private String password;
	
	//"id_career" => FK que hace referencia a la tabla CAREER dentro de LA TABLA STUDENT
	@ManyToOne
	@JoinColumn(name="id_career", nullable=false)
	private Career career;
	
	public Long getIdStudent() {
		return idStudent;
	}
	public void setIdStudent(Long idStudent) {
		this.idStudent = idStudent;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	//@JsonIgnore
	public Career getCareer() {
		return career;
	}
	public void setCareer(Career career) {
		this.career = career;
	}	
	
	
}
