package com.company.domain;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Repository
@Table(name="career")
@SequenceGenerator(name="seq", initialValue=1, allocationSize=100)
public class Career {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seq")
	@Column(name="id_career", length=50, nullable=false)
	private Long idCareer;
	
	@Column(name="name", length=50, nullable=false)
	private String name;
	
	// "career" => (private Career career;) dentro de LA CLASE STUDENT
	@OneToMany(mappedBy="career")
	private List<Student> students;
	
	public Long getIdCareer() {
		return idCareer;
	}
	public void setIdCareer(Long idCareer) {
		this.idCareer = idCareer;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@JsonIgnore
	public List<Student> getStudents() {
		return students;
	}
	public void setStudents(List<Student> students) {
		this.students = students;
	}
	
}
