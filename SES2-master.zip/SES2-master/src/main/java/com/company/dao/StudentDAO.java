package com.company.dao;

import org.springframework.data.repository.CrudRepository;

import com.company.domain.Student;

public interface StudentDAO extends CrudRepository<Student, Long> {

}
