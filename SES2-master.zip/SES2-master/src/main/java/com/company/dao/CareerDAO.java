package com.company.dao;

import org.springframework.data.repository.CrudRepository;

import com.company.domain.Career;

public interface CareerDAO extends CrudRepository<Career, Long> {

}
