package com.company.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.company.domain.Career;
import com.company.domain.Student;
import com.company.service.CareerService;
import com.company.service.StudentService;

@RestController
public class StudentController {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(StudentController.class);
	
	@Autowired
	private StudentService studentService;
	
	@Autowired
	private CareerService careerService;
	
	@RequestMapping(value = "/students", method = RequestMethod.GET)
	public List<Student> students(Model model){
		List<Student> students = studentService.listAllStudents();
		System.out.println("====>");
		for(Student student : students){
			System.out.println("====> " + student.getIdStudent() + " " +student.getName() + " " + student.getUsername() + " " + student.getPassword() + " " + student.getCareer().getName());
			//System.out.println("======> " + student.getName());
		}
		return students;
	}
	
	@RequestMapping(value = "/saveStudent", method = RequestMethod.GET)
	public String saveStudent(
			@RequestParam(value="name") String name,
			@RequestParam(value="username") String username,
			@RequestParam(value="password") String password,
			@RequestParam(value="idCareer") Long idCareer){
		
		System.out.println(name + " " + username + " " + password + " " + idCareer);
		
		Career career = careerService.findCareerById(idCareer);
		Student student = new Student();
		student.setName(name);
		student.setUsername(username);
		student.setPassword(password);
		student.setCareer(career);
		
		studentService.saveStudent(student);
		return "GUARDADO!";
	}
	
	@RequestMapping(value = "/updateStudent", method = RequestMethod.GET)
	public String updateStudent(
			@RequestParam(value="idStudent") Long idStudent,
			@RequestParam(value="name") String name,
			@RequestParam(value="username") String username,
			@RequestParam(value="password") String password,
			@RequestParam(value="idCareer") Long idCareer){
		
		System.out.println("*******> " + idStudent + " " + name + " " + username + " " + password + " " + idCareer);
		
		Career career = careerService.findCareerById(idCareer);
		
		Student student = studentService.findStudentById(idStudent);
		
		student.setName(name);
		student.setUsername(username);
		student.setPassword(password);
		student.setCareer(career);
		
		studentService.saveStudent(student);
		return "ACTUALIZADO!";
	}
	
	@RequestMapping(value = "/deleteStudent", method = RequestMethod.GET)
	public String deleteStudent(
			@RequestParam(value="idStudent") Long idStudent){
		
		Student student = studentService.findStudentById(idStudent);
		studentService.deleteStudent(student);
		
		return "ELIMINADO!";
	}
	
}
