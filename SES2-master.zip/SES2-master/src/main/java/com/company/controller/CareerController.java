package com.company.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.company.domain.Career;
import com.company.service.CareerService;

@RestController
public class CareerController {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(CareerController.class);
	
	@Autowired
	private CareerService careerService;
	
	@RequestMapping(value = "/careers", method = RequestMethod.GET)
	public List<Career> careers(){
		return careerService.listAllCareers();
	}
	
	@RequestMapping(value = "/saveCareer", method = RequestMethod.POST)
	public String saveCareer(@RequestBody Career career){
		System.out.println(career.getName());
		careerService.saveCareer(career);
		return "GUARDADO!";
	}
	
	@RequestMapping(value = "/updateCareer", method = RequestMethod.PUT)
	public String updateCareer(@RequestBody Career career){
		System.out.println(career.getName());
		careerService.saveCareer(career);
		return "ACTUALIZADO!";
	}
	
	@RequestMapping(value = "/deleteCareer", method = RequestMethod.DELETE)
	public String deleteCareer(@RequestBody Career career){
		System.out.println(career.getName());
		careerService.deleteCareer(career);;
		return "ELIMINADO!";
	}
}
