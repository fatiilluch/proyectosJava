package com.company.service;

import java.util.List;

import com.company.domain.Career;

public interface CareerService {
	void saveCareer(Career career);
	void deleteCareer(Career career);	
	List<Career> listAllCareers();
	Career findCareerById(Long id);
}
