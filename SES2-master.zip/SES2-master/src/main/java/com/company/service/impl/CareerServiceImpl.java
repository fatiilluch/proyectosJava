package com.company.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.company.dao.CareerDAO;
import com.company.domain.Career;
import com.company.service.CareerService;

@Service
public class CareerServiceImpl implements CareerService {

	private static final Logger LOGGER = LoggerFactory.getLogger(CareerServiceImpl.class);
	
	@Autowired
	private CareerDAO careerDAO;
	
	@Override
	public void saveCareer(Career career) {
		LOGGER.debug("CareerServiceImpl: Into ===> saveCareer()");
		careerDAO.save(career);
	}

	@Override
	public void deleteCareer(Career career) {
		LOGGER.debug("CareerServiceImpl: Into ===> deleteCareer()");
		careerDAO.delete(career);
	}

	@Override
	public List<Career> listAllCareers() {
		LOGGER.debug("CareerServiceImpl: Into ===> listAllCareers()");
		return (List<Career>) careerDAO.findAll();
	}

	@Override
	public Career findCareerById(Long id) {
		LOGGER.debug("CareerServiceImpl: Into ===> findCareerById()");
		return careerDAO.findOne(id);
	}

}
