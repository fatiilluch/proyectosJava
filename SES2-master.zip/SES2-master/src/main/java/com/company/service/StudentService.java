package com.company.service;

import java.util.List;

import com.company.domain.Student;

public interface StudentService {
	void saveStudent(Student student);
	void deleteStudent(Student student);
	List<Student> listAllStudents();
	Student findStudentById(Long id);
}
