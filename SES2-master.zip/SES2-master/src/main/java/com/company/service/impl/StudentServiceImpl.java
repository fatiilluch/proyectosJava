package com.company.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.company.dao.StudentDAO;
import com.company.domain.Student;
import com.company.service.StudentService;

@Service
public class StudentServiceImpl implements StudentService{

	@Autowired
	private StudentDAO studentDAO;
	
	@Override
	public void saveStudent(Student student) {
		studentDAO.save(student);
	}

	@Override
	public void deleteStudent(Student student) {
		studentDAO.delete(student);
	}

	@Override
	public List<Student> listAllStudents() {
		return (List<Student>) studentDAO.findAll();
	}

	@Override
	public Student findStudentById(Long id) {
		return studentDAO.findOne(id);
	}

}
