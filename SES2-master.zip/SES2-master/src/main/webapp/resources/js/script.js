$(document).ready(function(){
	
	/* ================================================================================= */
	/*									CAREERS											 */
	/* ================================================================================= */
	
	
	/* ============================= */
	/*          TODAS CARRERAS       */
	/* ============================= */
	
	$("#btnCareers").click(allCareers);
	
	function allCareers(){
		modeloDeEventos("allCareers");
		
		var fullUrl = $("#jspPath").val() + "/careers";
		var htmlStr;
		
		$.ajax({
			type:			"GET",
			contentType : 	"application/json",
			url:			fullUrl,
			//data:			{"number":"5"},
			datatype:		"json",
			success:		function(careers){								
								if(jQuery.isEmptyObject(careers)){
									$("#message").text("No hay Carreras aun!");
								}
								else{
									htmlStr = tabulizarCareer(["Id","Name"], careers);
									$("#displayTable").html(htmlStr);
								}
								
							}
		});
	}
	
	function tabulizarCareer(titulos, careers){
		var htmlStr = "";

		//Titulos
		htmlStr +="<table class='table table-bordered table-striped'><tr>";
		for(titulo in titulos){
			htmlStr += "<th>" + titulos[titulo] + "</th>";
		}
		htmlStr += "<th>Update</th><th>Delete</th></tr>";

		//Contenido
		for(row in careers){
			htmlStr += 	"<tr>" +
							"<td class='idCareer'>" + careers[row].idCareer + "</td>" + 
							"<td class='nameCareer'>" + careers[row].name + "</td>" +
							"<td><input type='button' value='Update' class='btn btn-success btnUpdateCareer'></td>" +
							"<td><input type='button' value='Delete' class='btn btn-danger btnDeleteCareer'></td>" +
						"</tr>";
		}
		
		//Cierre Tabla
		htmlStr += "</table>";

		return htmlStr;
		
	}
	
	/* ============================= */
	/*         GUARDAR CARRERA       */
	/* ============================= */
	
	$(document).on('click', '#btnSaveCareer', function(){

		var fullUrl = $("#jspPath").val() + "/saveCareer";
		var htmlStr;
		
		var career = {};
		career["name"] = $("#name").val();

		$.ajax({
			type:			"POST",
			contentType : 	"application/json",
			url:			fullUrl,
			data:			JSON.stringify(career),
			datatype:		"text",
			success:		function(message){
								alert(message);
								allCareers();
							}
		});
		
	});
	
	/* ============================= */
	/*      ACTUALIZAR CARRERA       */
	/* ============================= */
	
	$(document).on('click', '.btnUpdateCareer', function(){
		modeloDeEventos("nuevo");
		
		var idCareer = $(this).closest("tr").find(".idCareer").text();
		var nameCareer = $(this).closest("tr").find(".nameCareer").text();

		var htmlStr = "";
		
		htmlStr += 
			"<p>ACTUALIZANDO CARRERA</p><br/>" +
			"<div class='form-group'>" +
			"<input type='hidden' id='idUpdateFormCareer' value='"+ idCareer +"'/>" +
			"</div>" +
			"<div class='form-group'>" +
			"<input type='text' placeholder='Nombre Carrera' id='nameUpdateFormCareer' class='form-control' value='"+ nameCareer +"'/>" +
			"</div>" +
			"<div class='form-group'>" +
			"<input type='button' value='Actualizar' id='btnUpdateFormCareer' class='form-control btn btn-success' />" +
			"</div>";
		$("#displayForm").html(htmlStr);
	});
	
	$(document).on('click', '#btnUpdateFormCareer', function(){
		
		var idCareer = $("#idUpdateFormCareer").val();
		var nameCareer = $("#nameUpdateFormCareer").val();
		
		var fullUrl = $("#jspPath").val() + "/updateCareer";
		var htmlStr = "";
		
		var career = {};
		//idCareer, name === campos de la clase Career
		career["idCareer"] = idCareer;
		career["name"] = nameCareer;
		
		$.ajax({
			type:			"PUT",
			contentType : 	"application/json",
			url:			fullUrl,
			data:			JSON.stringify(career),
			datatype:		"text",
			success:		function(message){
								alert(message);
								allCareers();
							}
		});		
		
	});
	
	/* ============================= */
	/*         ELIMINAR CARRERA       */
	/* ============================= */
	
	$(document).on('click', '.btnDeleteCareer', function(){
		var idCareer = $(this).closest("tr").find(".idCareer").text();
		var nameCareer = $(this).closest("tr").find(".nameCareer").text();
		
		var fullUrl = $("#jspPath").val() + "/deleteCareer";
		var htmlStr;
		
		var career = {};
		career["idCareer"] = idCareer;
		career["name"] = nameCareer;
		
		$.ajax({
			type:			"DELETE",
			contentType : 	"application/json",
			url:			fullUrl,
			data:			JSON.stringify(career),
			datatype:		"text",
			success:		function(message){
								alert(message);
								allCareers();
							}
		});		
	});
		
	
	
	/* ================================================================================= */
	/*									STUDENTS										 */
	/* ================================================================================= */
	
	/* ============================= */
	/*       TODOS ESTUDIANTES       */
	/* ============================= */
	
	$("#btnStudents").click(allStudents);
	
	function allStudents(){
		modeloDeEventos("allStudents");
		
		var fullUrl = $("#jspPath").val() + "/students";
		var htmlStr;
		
		$.ajax({
			type:			"GET",
			contentType : 	"application/json",
			url:			fullUrl,
			//data:			{"number":"5"},
			datatype:		"json",
			success:		function(students){								
								if(jQuery.isEmptyObject(students)){
									$("#message").text("No hay Estudiantes aun!");
								}
								else{
									htmlStr = tabulizarStudent(["Id","Name","Username","Password","Carrera"], students);
									$("#displayTable").html(htmlStr);
								}								
							}
		});
	}
	
	function tabulizarStudent(titulos, students){
		var htmlStr = "";

		//Titulos
		htmlStr +="<table class='table table-bordered table-striped'><tr>";
		for(titulo in titulos){
			htmlStr += "<th>" + titulos[titulo] + "</th>";
		}
		htmlStr += "<th>Update</th><th>Delete</th></tr>";

		//Contenido
		for(row in students){
			htmlStr += 	"<tr>" +
							"<td class='idStudent'>" + students[row].idStudent + "</td>" + 
							"<td class='nameStudent'>" + students[row].name + "</td>" +
							"<td class='usernameStudent'>" + students[row].username + "</td>" +
							"<td class='passwordStudent'>" + students[row].password + "</td>" +
							"<td class='nameCareer'>" + students[row].career.name + "</td>" +
							"<td>" +
								"<input type='text' value='"+ students[row].career.idCareer +"' class='idCareerStudent' hidden>" +
								"<input type='button' value='Update' class='btn btn-success btnUpdateStudent'></td>" +
							"<td><input type='button' value='Delete' class='btn btn-danger btnDeleteStudent'></td>" +
						"</tr>";
		}
		
		//Cierre Tabla
		htmlStr += "</table>";

		return htmlStr;
		
	}
	
	/* ============================= */
	/*         GUARDAR STUDENT       */
	/* ============================= */
	
	$(document).on('click', '#btnSaveStudent', function(){

		var fullUrl = $("#jspPath").val() + "/saveStudent";
		var htmlStr;
		
		name = $("#name").val();
		username = $("#username").val();
		password = $("#password").val();
		idCareer = $("#selCareers").val();
		
		$.ajax({
			type:			"GET",
			//contentType : 	"application/json",
			url:			fullUrl,
			data:			{"name":name,"username":username,"password":password,"idCareer":idCareer},
			datatype:		"text",
			success:		function(message){
								alert(message);
								allStudents();
							}
		});
		
	});

	/* ============================= */
	/*   ACTUALIZAR ESTUDIANTE       */
	/* ============================= */
	
	$(document).on('click', '.btnUpdateStudent', function(){
		modeloDeEventos("nuevo");
		
		var idStudent = $(this).closest("tr").find(".idStudent").text();
		var nameStudent = $(this).closest("tr").find(".nameStudent").text();
		var usernameStudent = $(this).closest("tr").find(".usernameStudent").text();
		var passwordStudent = $(this).closest("tr").find(".passwordStudent").text();
		var idCareerStudent = $(this).closest("tr").find(".idCareerStudent").val();
		
		/*TRAEMOS TODAS LAS CARREAS*/
		var fullUrl = $("#jspPath").val() + "/careers";
		
		$.ajax({
			type:			"GET",
			contentType : 	"application/json",
			url:			fullUrl,
			//data:			{"number":"5"},
			datatype:		"json",
			/**
			 * 
			 */
			success:		function(careers){								
								var htmlStr = "";
								
								htmlStr += 
									"<p>ACTUALIZANDO ESTUDIANTE</p><br/>" +
									"<div class='form-group'>" +
									"<input type='hidden' id='idUpdateFormStudent' class='form-control' value='"+ idStudent + "'/>" +
									"<input type='text' id='nameUpdateFormStudent' class='form-control' value='"+ nameStudent + "'/>" +
									"</div>" +
									"<div class='form-group'>" +
									"<input type='text' id='usernameUpdateFormStudent' class='form-control' value='"+ usernameStudent + "'/>" +
									"</div>" +
									"<div class='form-group'>" +
									"<input type='text' id='passwordUpdateFormStudent' class='form-control' value='"+ passwordStudent + "'/>" +
									"</div>" +
									"<div class='form-group'>" +
									"<label for='selCareersUpdateFormStudent'>Seleccione una Carrera</label>" +
									"<select class='form-control' id = 'selCareersUpdateFormStudent'>";
									
								for(row in careers){
									if(careers[row].idCareer === parseInt(idCareerStudent)){
										htmlStr += "<option value='"+ careers[row].idCareer +"' selected>"+ careers[row].name +"</option>";
									}
									else{
										htmlStr += "<option value='"+ careers[row].idCareer +"'>"+ careers[row].name +"</option>";
									}
									
								}
									
								htmlStr += 
									"</select>" +
									"</div>" +
									"<div class='form-group'>" +
									"<input type='button' value='Actualizar' id='btnUpdateFormStudent' class='form-control btn btn-primary' />" +
									"</div>";
								$("#displayForm").html(htmlStr);
							}
		});
		
		
	});
	
	$(document).on('click', '#btnUpdateFormStudent', function(){
		
		var idStudent = $("#idUpdateFormStudent").val();
		var name = $("#nameUpdateFormStudent").val();
		var username = $("#usernameUpdateFormStudent").val();
		var password = $("#passwordUpdateFormStudent").val();
		var idCareer = $("#selCareersUpdateFormStudent").val();
		
		var fullUrl = $("#jspPath").val() + "/updateStudent";
		var htmlStr = "";
		
		$.ajax({
			type:			"GET",
			//contentType : 	"application/json",
			url:			fullUrl,
			data:			{"idStudent":idStudent,"name":name,"username":username,"password":password,"idCareer":idCareer},
			datatype:		"text",
			success:		function(message){
								alert(message);
								allStudents();
							}
		});		
		
	});
	
	/* ============================= */
	/*         ELIMINAR ESTUDIANTE   */
	/* ============================= */
	
	$(document).on('click', '.btnDeleteStudent', function(){
		var idStudent = $(this).closest("tr").find(".idStudent").text();
		
		var fullUrl = $("#jspPath").val() + "/deleteStudent";
		var htmlStr;
		
		$.ajax({
			type:			"GET",
			//contentType : 	"application/json",
			url:			fullUrl,
			data:			{"idStudent":idStudent},
			datatype:		"text",
			success:		function(message){
								alert(message);
								allStudents();
							}
		});		
	});
	
	/* ================================================================================= */
	/*									GENERALES										 */
	/* ================================================================================= */
	
	/* ============================= */
	/*         click on: Nuevo       */
	/* ============================= */
	
	$("#btnNew").click(function(){
		modeloDeEventos("nuevo");
		
		var title = $("#subtitle").text();
		var htmlStr = "";
		
		if(title === "CARRERAS"){
			htmlStr += 
				"<p>CREANDO NUEVA CARRERA</p><br/>" +
				"<div class='form-group'>" +
				"<input type='text' placeholder='Nombre Carrera' id='name' class='form-control'/>" +
				"</div>" +
				"<div class='form-group'>" +
				"<input type='button' value='Guardar' id='btnSaveCareer' class='form-control btn btn-primary' />" +
				"</div>";
			$("#displayForm").append(htmlStr);
		}
		if(title === "ESTUDIANTES"){
			var fullUrl = $("#jspPath").val() + "/careers";
			
			$.ajax({
				type:			"GET",
				contentType : 	"application/json",
				url:			fullUrl,
				//data:			{"number":"5"},
				datatype:		"json",
				success:		function(careers){								
									if(jQuery.isEmptyObject(careers)){
										$("#message").text("No hay Carreras aun!");
									}
									else{
										htmlStr += 
											"<p>CREANDO NUEVO ESTUDIANTE</p><br/>" +
											"<div class='form-group'>" +
											"<input type='text' placeholder='Nombre Estudiante' id='name' class='form-control'/>" +
											"</div>" +
											"<div class='form-group'>" +
											"<input type='text' placeholder='Username' id='username' class='form-control'/>" +
											"</div>" +
											"<div class='form-group'>" +
											"<input type='text' placeholder='Password' id='password' class='form-control'/>" +
											"</div>" +
											"<div class='form-group'>" +
											"<label for='selCareers'>Seleccione una Carrera</label>" +
											"<select class='form-control' id = 'selCareers'>";
											
										for(row in careers){
											htmlStr += 
												"<option value='"+ careers[row].idCareer +"'>"+ careers[row].name +"</option>";
										}
											
										htmlStr += 
											"</select>" +
											"</div>" +
											"<div class='form-group'>" +
											"<input type='button' value='Guardar' id='btnSaveStudent' class='form-control btn btn-primary' />" +
											"</div>";
										$("#displayForm").append(htmlStr);										
									}									
								}
			});
		}
	});
	
	/* ============================= */
	/*       Modelo de Eventos       */
	/* ============================= */

	function modeloDeEventos(evento){
		if(evento === "allCareers"){
			$("#displayTable").text("");
			$("#displayForm").text("");
			$("#message").text("");
			$("#btnNew").show();
			$("#subtitle").html("CARRERAS");
		}
		if(evento === "allStudents"){
			$("#displayTable").text("");
			$("#displayForm").text("");
			$("#message").text("");
			$("#btnNew").show();
			$("#subtitle").html("ESTUDIANTES");
		}
		if(evento === "nuevo"){
			$("#displayTable").text("");
			$("#displayForm").text("");
			$("#message").text("");
			$("#btnNew").hide();
		}
	}
	
}); //document.ready
	